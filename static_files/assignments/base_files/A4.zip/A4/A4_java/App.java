package A4;

import jdk.jshell.spi.ExecutionControl.NotImplementedException;

public class App {

    public enum Config 
    {
        //Implement Config Enum
    }

    public static String ChooseBest(Config c){
        //Implement Method
        return null;
    }

    

    public static void main(String[] args) {
        
    }
}
