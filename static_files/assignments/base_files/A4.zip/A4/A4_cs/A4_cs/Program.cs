﻿using System;

namespace A4_cs
{
    public enum Config
    {
        //Implement Enum
    }
    public class MemoryHeap
    {

        public void Allocate(int bytes)
        {
            //TODO
        }
        public void DeAllocate()
        {
            //TODO
        }
    }

    public class Memory
    {
        //Implement Memory
    }
    public class Graphic
    {
        //Implement Graphic
    }
    public class Cpu
    {
        //Implement Cpu
    }

    public class Program
    {
        static void Main(string[] args) { }
        
        public static string ChooseBest(Config c)
        {
            return null;
        }
        public static void SwapConfigs(object o1, object o2)
        {
            //Implement Method
        }
    }
}
