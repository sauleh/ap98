﻿using System;
using System.IO;

namespace Calculator
{
    public class DivideOperator : BinaryOperator
    {
        public DivideOperator(TextReader reader)
        {
            throw new NotImplementedException();
        }

        public override string OperatorSymbol => throw new NotImplementedException();

        public override double Evaluate() => throw new NotImplementedException();
    }
}