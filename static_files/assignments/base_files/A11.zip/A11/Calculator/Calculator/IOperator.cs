﻿namespace Calculator
{
    public interface IOperator
    {
        string OperatorSymbol { get; }
    }
}