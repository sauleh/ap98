﻿using System.Collections.Generic;

namespace A2_cs
{
    public class Store
    {
        public string Name;
        public List<Category> Categories;
        public List<Cart> Carts;
        public Store(string name, List<Category> categories, List<Cart> carts)
        {
            //TODO
        }
        public void AddCart(Cart c)
        {
            //TODO
        }
        public void AddCategory(Category c)
        {
            //TODO
        }

        public Product Bestselling()
        {
            //TODO
            return null;
        }
        public Product MostPopular()
        {
            //TODO
            return null;
        }
    }
}

