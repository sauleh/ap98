﻿using System.Collections.Generic;

namespace A2_cs
{
    public class Category
	{
		public ID Id;
		public List<Product> Products;
		public Category(ID id, List<Product> products)
		{
            //TODO
        }
        public void AddProduct(Product p)
		{
            //TODO
        }
        public List<Product> FilterByPrice(int lower,int upper)
		{
            //TODO
            return null;
        }
    }
}

