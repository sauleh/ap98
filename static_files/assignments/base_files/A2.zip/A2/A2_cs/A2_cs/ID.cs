﻿namespace A2_cs
{
    public enum ID
    {
        Mobile = 1,
        Laptop = 2,
        Tablet = 3
    }
}

