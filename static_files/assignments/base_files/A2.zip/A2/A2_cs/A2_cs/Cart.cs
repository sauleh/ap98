﻿using System.Collections.Generic;

namespace A2_cs
{
    public class Cart
	{
		public string Owner;
		public List<Product> Products;
		public Cart(string owner, List<Product> products)
		{
			//TODO
		}
		public void AddProduct(Product p)
		{
            //TODO
        }
        public long CalculatePrice()
		{
            //TODO
            return 0;
        }

    }
}

