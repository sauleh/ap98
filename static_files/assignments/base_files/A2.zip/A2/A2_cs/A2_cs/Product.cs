﻿namespace A2_cs
{
    public class Product
	{
		public ID Id;
		public string Name;
		public int Price;
		public double Rate;
		public Product(ID id , string name, int price, double rate)
		{
            //TODO
        }
    }
}

