class Person:
    def __init__(self,id,name,contacts,chats):
        #TODO
        x=1

    def AddContact(self,PERSON):
        #TODO
        return 0

    def SendMessage(self,message):
        #TODO  
        return 0 

class Message:
    def __init__(self,source,destination,context):
        #TODO
        x=1


