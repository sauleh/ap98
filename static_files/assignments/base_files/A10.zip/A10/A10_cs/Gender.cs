﻿namespace A10_cs
{
    public enum Gender
    {
        Male,
        Female
    }
}
