﻿using System.Collections;
using System.Collections.Generic;

namespace A10_cs
{
    public class Author  
    {
		//TODO
    }
}
