namespace A10_cs
{
    public class Book
    {
        //TODO
    }
}