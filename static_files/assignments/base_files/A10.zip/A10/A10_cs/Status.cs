﻿namespace A10_cs
{
    public enum Status
    {
        Reserved,
        Free
    }
}