using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace A10_cs
{
    public class Reader
    {
        public DateTime enterTime;
        public List<Tuple<Book,DateTime>> borrowed_Books;
        public List<Notifable> notifables;
        
        //TODO (Constructor)
        
        public void borrow_book(Book b,DateTime now)
        {
            //TODO
        }
        
        public Task<long> return_book(long book_id,DateTime now)
        {
			//TODO
        }

        public IEnumerable<string> show_book()
        {
            //TODO
			//Should Implement With Linq
        }
    }
}
