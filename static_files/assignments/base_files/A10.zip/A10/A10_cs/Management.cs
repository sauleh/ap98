﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace A10_cs
{
    public class Management
    {
        public List<Book> allBooks;
        public List<Reader> allMembers;
		
        //TODO
		
        public void Reload(DateTime now)
        {
            //TODO
			//Should Implement With Linq
        }
    }
}
