﻿using System.Collections.Generic;

namespace A10_cs
{
    public class Notifable
    {
		//TODO
    }
    public class Email
    {
        //TODO
    }
    public class Mobile
    {
        //TODO
    }
}
