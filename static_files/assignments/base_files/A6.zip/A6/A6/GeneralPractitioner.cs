﻿using System;
using System.Collections.Generic;

namespace A6
{
    public class GeneralPractitioner 
    {
        
    }
}
