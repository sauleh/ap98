﻿namespace A6
{
    public class Patient 
    {
        
    }
}
