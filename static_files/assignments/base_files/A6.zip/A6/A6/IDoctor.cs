﻿using System.Collections.Generic;

namespace A6
{
    public interface IDoctor
    {
        
    }
}
