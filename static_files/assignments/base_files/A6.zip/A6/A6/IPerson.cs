﻿namespace A6
{
    public interface IPerson
    {
        
    }
}
