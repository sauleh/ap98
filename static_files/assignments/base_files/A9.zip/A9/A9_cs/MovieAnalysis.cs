﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace A9_cs
{
    public class MovieAnalysis
    {
        public MovieData[] MovieDatas;
        public MovieAnalysis(string path)
        {
            string[] lines = File.ReadAllLines(path);
            List<MovieData> Movies = new List<MovieData>();
            for (int i = 1; i < lines.Length - 1; i++)
                try
                {
                    var t = new MovieData(lines[i].Replace(" ", "").Split(','));
                    Movies.Add(t);
                }
                catch { }
            this.MovieDatas = Movies.ToArray();
        }
        //اطلاعات فیلم ها در آرایه ی MovieDatas ذخیره شده اند
        public long AllDataCount()
        {
            throw NotImplementedException();
        }
        public long AllMoviesIn2014()
        {
            throw NotImplementedException();
        }
        public string[] AllAmbiguous()
        {
            throw NotImplementedException();
        }
        public string MostDirector()
        {
            throw NotImplementedException();
        }
        public string[] FiveBestMovies()
        {
            throw NotImplementedException();
        }
        public string DirectorWithMaximomDuration()
        {
            throw NotImplementedException();
        }
        public Tuple<string, string> MinMaxCriticMovie()
        {
            throw NotImplementedException();
        }
        public long? YearWithMostMovies()
        {
            throw NotImplementedException();
        }
        public string MostEfficientMovie()
        {
            throw NotImplementedException();
        }
        public string[] MoviesAppropriate(ContentRating cr)
        {
            throw NotImplementedException();
        }
        public string[] BestDirectorName()
        {
            throw NotImplementedException();
        }
        public string MostActorMovie()
        {
            throw NotImplementedException();
        }
        public string ActionMovies()
        {
            throw NotImplementedException();
        }
        public double? DramaMoviesOfJohnnyDepp()
        {
            throw NotImplementedException();
        }
    }
}
