﻿using System;
using System.IO;

namespace A8_cs
{

    public class SingleFileWatcher: IDisposable
    {
        private FileSystemWatcher Watcher;
		
    }
}