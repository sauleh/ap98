﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace A8_cs
{
    public static class ActionTools
    {
        public static long CallSequential(params Action[] actions)
        {
			throw new NotImplementedException();
        }

        public static long CallParallel(params Action[] actions)
        {
			throw new NotImplementedException();
        }

        public static long CallParallelThreadSafe(int count, params Action[] actions)
        {
            throw new NotImplementedException();
        }


        public static async Task<long> CallSequentialAsync(params Action[] actions)
        {
           throw new NotImplementedException();
        }

        public static async Task<long> CallParallelAsync(params Action[] actions)
        {
           throw new NotImplementedException();
        }

        public static async Task<long> CallParallelThreadSafeAsync(int count, params Action[] actions)
        {
			throw new NotImplementedException();
        }
    }
}