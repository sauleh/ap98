﻿using System;
using System.Threading;

namespace A8_cs
{   
    public class SingleReminderThreadPool : ISingleReminder
    {
        
    }
}