﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace A8_cs
{
    public class SingleReminderTask : ISingleReminder
    {
        Task ReiminderTask = null;
        
    }
}