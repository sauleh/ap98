﻿using System;
using System.IO;

namespace A8_cs
{
    public enum ObserverType { Create, Delete }

    public class DirectoryWatcher: IDisposable
    {
       
    }
}